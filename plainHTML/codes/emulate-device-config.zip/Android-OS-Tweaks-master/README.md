This code includes few scripts to emulate the Android CPU load, memory and frequency usage of smart phones. 
