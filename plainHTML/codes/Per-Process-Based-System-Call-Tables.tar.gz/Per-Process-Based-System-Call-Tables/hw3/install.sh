insmod fsl_os_svector.ko
insmod fsl_os_svector1.ko
insmod fsl_os_svector2.ko
insmod fsl_os_sci.ko
