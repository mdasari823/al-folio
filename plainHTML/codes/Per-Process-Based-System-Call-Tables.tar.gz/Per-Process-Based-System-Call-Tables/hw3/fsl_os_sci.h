#ifndef FSL_OS_SCI_H
#define FSL_OS_SCI_H

int fsl_os_override_syscalls(void);

int fsl_os_restore_syscalls(void);

#endif
