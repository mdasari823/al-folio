rmmod fsl_os_sci
rmmod fsl_os_svector1
rmmod fsl_os_svector2
rmmod fsl_os_svector

